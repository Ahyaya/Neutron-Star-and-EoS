#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include<direct.h>
#define pi 3.14159265358979
#define Mscale 2.033931261665867e5
#define c 2.99792458e8
#define Max(x,y) (((x)>(y))?(x):(y))
#define Abs(z) (((z)>(0))?(z):(-z))
FILE *scanlog;
double temp_r,temp_m,temp_p,temp_rho,temp_y,temp_cs2,temp_R,temp_M,temp_k2,p_surf,rho_core,EOS_lgrho[2000],EOS_lgp[2000];
int length_EOS=0,loopTOV=1;
char sT[30];

double pchip(cp)
double cp;
{
if(cp<p_surf)
{loopTOV=0;return 0;}

double logp=log10(cp),logrho,crho,a0,a1,b0,b1,h0,h1,h2,d0,d1,d2,k0,k1,dydx;
int n=length_EOS-1;
int np=n;
for(;n>0;n--)
{
if(logp>EOS_lgp[n-1])
{
if((n>1)&&(n<np))
{

h0=EOS_lgp[n-1]-EOS_lgp[n-2];
h1=EOS_lgp[n]-EOS_lgp[n-1];
h2=EOS_lgp[n+1]-EOS_lgp[n];
d0=(EOS_lgrho[n-1]-EOS_lgrho[n-2])/h0;
d1=(EOS_lgrho[n]-EOS_lgrho[n-1])/h1;
d2=(EOS_lgrho[n+1]-EOS_lgrho[n])/h2;
k0=3*d0*d1/(d0+d1+(h0*d0+h1*d1)/(h0+h1));
k1=3*d2*d1/(d2+d1+(h2*d2+h1*d1)/(h2+h1));

}else if(n==1){

h1=EOS_lgp[n]-EOS_lgp[n-1];
h2=EOS_lgp[n+1]-EOS_lgp[n];
d1=(EOS_lgrho[n]-EOS_lgrho[n-1])/h1;
d2=(EOS_lgrho[n+1]-EOS_lgrho[n])/h2;
k0=((2*h1+h2)*d1-h1*d2)/(h1+h2);
if(k0*d1<=0)
{
k0=0;
}else if((d1*d2<=0)&&(k0*k0>9*d1*d1))
{
k0=3*d1;}
k1=3*d2*d1/(d2+d1+(h2*d2+h1*d1)/(h2+h1));

}else if(n==np){

h0=EOS_lgp[n-1]-EOS_lgp[n-2];
h1=EOS_lgp[n]-EOS_lgp[n-1];
d0=(EOS_lgrho[n-1]-EOS_lgrho[n-2])/h0;
d1=(EOS_lgrho[n]-EOS_lgrho[n-1])/h1;
k0=3*d0*d1/(d0+d1+(h0*d0+h1*d1)/(h0+h1));
k1=((2*h1+h0)*d1-h1*d0)/(h1+h0);
if(k1*d1<=0)
{k1=0;
}else if((d0*d1<=0)&&(k1*k1>9*d1*d1))
{
k1=3*d1;
}


}else{
printf("Warning: pchip error 1\n");
fprintf(scanlog,"Warning: pchip error 1\n");
return 0;
}


a0=(1+2/h1*(logp-EOS_lgp[n-1]))*(logp-EOS_lgp[n])*(logp-EOS_lgp[n])/h1/h1;
a1=(1-2/h1*(logp-EOS_lgp[n]))*(logp-EOS_lgp[n-1])*(logp-EOS_lgp[n-1])/h1/h1;
b0=(logp-EOS_lgp[n-1])*(logp-EOS_lgp[n])*(logp-EOS_lgp[n])/h1/h1;
b1=(logp-EOS_lgp[n])*(logp-EOS_lgp[n-1])*(logp-EOS_lgp[n-1])/h1/h1;
logrho=a0*EOS_lgrho[n-1]+a1*EOS_lgrho[n]+k0*b0+k1*b1;
crho=pow(10,logrho);
dydx=6/h1/h1/h1*(logp-EOS_lgp[n])*(logp-EOS_lgp[n-1])*(EOS_lgrho[n-1]-EOS_lgrho[n])+k0/h1/h1*(logp-EOS_lgp[n])*(3*logp-EOS_lgp[n]-EOS_lgp[n-1]-EOS_lgp[n-1])+k1/h1/h1*(logp-EOS_lgp[n-1])*(3*logp-EOS_lgp[n-1]-EOS_lgp[n]-EOS_lgp[n]);
temp_cs2=cp/crho/dydx;
return(crho);

}
}
printf("Warning: pchip error 2\n");
fprintf(scanlog,"Warning: pchip error 2\n");
return 0;
}


void fE(fr,fm,fp,frho,fy,h)
double fr,fm,fp,frho,fy,h;
{
temp_r=fr+h;
temp_m=fm+4*pi*fr*fr*frho*h;
temp_p=h*(frho+fp)*(fm+4*pi*fr*fr*fr*fp)/(2*fm*fr-fr*fr)+fp;
temp_rho=pchip(temp_p);
temp_y=fy+h*(-fy*fy/fr-fy/fr*(1+4*pi*fr*fr*(fp-frho))/(1-2*fm/fr)-fr*(4*pi*(5*frho+9*fp+(fp+frho)/temp_cs2)/(1-2*fm/fr)-6/fr/fr/(1-2*fm/fr)-4/fr/fr/fr/fr/(1-2*fm/fr)/(1-2*fm/fr)*(fm+4*pi*fr*fr*fr*fp)*(fm+4*pi*fr*fr*fr*fp)));
return;
}

double interp_rho2p(crho)
double crho;
{
double logp,logrho=log10(crho),cp;
int n=length_EOS-1;
for(;n>0;n--)
{
if(logrho>EOS_lgrho[n-1])
{
logp=(logrho-EOS_lgrho[n-1])*(EOS_lgp[n]-EOS_lgp[n-1])/(EOS_lgrho[n]-EOS_lgrho[n-1])+EOS_lgp[n-1];
cp=pow(10,logp);
return(cp);
}
}
printf("Warning:rho2p interpolation error\n");
fprintf(scanlog,"Warning:rho2p interpolation error\n");
return(0);
}

void getRM(prhoc)
double prhoc;
{
loopTOV=1;
double frhoc=prhoc*6.6741e-11;
double h=1e-8,localRes,r=h,y=2;
double m=4/3*r*r*r*frhoc,p=interp_rho2p(frhoc),rho=frhoc;
double m11,p11,rho11,y11,m21,p21,rho21,y21,m22,p22,rho22,y22,m31,p31,rho31,y31,m61,p61,rho61,y61,m62,p62,rho62,y62,K_m,K_p,K_rho,K_y,A_m,A_p,A_rho,A_y,B_m,B_p,B_rho,B_y,RK_m,RK_p,RK_rho,RK_y,TR_m,TR_p,TR_rho,TR_y;
double res1,res2,res3;
while(1)
{
fE(r,m,p,rho,y,h);
m11=temp_m;
p11=temp_p;
rho11=temp_rho;
y11=temp_y;
fE(r,m,p,rho,y,0.5*h);
m21=temp_m;
p21=temp_p;
rho21=temp_rho;
y21=temp_y;
fE(r+0.5*h,m21,p21,rho21,y21,0.5*h);
m22=temp_m;
p22=temp_p;
rho22=temp_rho;
y22=temp_y;
fE(r,m,p,rho,y,h/3);
m31=temp_m;
p31=temp_p;
rho31=temp_rho;
y31=temp_y;
fE(r,m,p,rho,y,h/6);
m61=temp_m;
p61=temp_p;
rho61=temp_rho;
y61=temp_y;
fE(r+h/6,m61,p61,rho61,y61,h/6);
m62=temp_m;
p62=temp_p;
rho62=temp_rho;
y62=temp_y;
K_m=m22-m21;
K_p=p22-p21;
K_rho=rho22-rho21;
K_y=y22-y21;
fE(r+0.5*h,m+K_m,p+K_p,rho+K_rho,y+K_y,h);
A_m=temp_m;
A_p=temp_p;
A_rho=temp_rho;
A_y=temp_y;
fE(r+h,A_m-K_m,A_p-K_p,A_rho-K_rho,A_y-K_y,h);
B_m=temp_m;
B_p=temp_p;
B_rho=temp_rho;
B_y=temp_y;

if(loopTOV<1) break;

RK_m=0.5*(m+K_m)+(m11+A_m+B_m)/6;
RK_p=0.5*(p+K_p)+(p11+A_p+B_p)/6;
RK_rho=0.5*(rho+K_rho)+(rho11+A_rho+B_rho)/6;
RK_y=0.5*(y+K_y)+(y11+A_y+B_y)/6;
TR_m=m22+9*(m62-m31);
TR_p=p22+9*(p62-p31);
TR_y=y22+9*(y62-y31);
res1=Abs((RK_m-TR_m)/RK_m);
res2=Abs((RK_p-TR_p)/RK_p);
res3=Abs((RK_y-TR_y)/RK_y);

localRes=Max(res3,Max(res1,res2));

if(localRes<5e-6 && h<8e-8)
{
r=r+h;
m=RK_m;
p=RK_p;
rho=RK_rho;
y=RK_y;
h=h*2;
}else if(localRes>2e-4 && h>1.25e-9){
h=h*0.5;
}else{
r=r+h;
m=RK_m;
p=RK_p;
rho=RK_rho;
y=RK_y;
}
}
double bt=m/r;
temp_R=r*c*1e-3;
temp_M=m*Mscale;
temp_k2=1.6*bt*bt*bt*bt*bt*(1-2*bt)*(1-2*bt)*(2-y+2*bt*(y-1))/(2*bt*(6-3*y+3*bt*(5*y-8))+4*bt*bt*bt*(13-11*y+bt*(3*y-2)+2*bt*bt*(1+y))+3*(1-2*bt)*(1-2*bt)*(2-y+2*bt*(y-1))*log(1-2*bt));
return;
}

int ManualS(EOSname)
char EOSname[50];
{
FILE *inf,*outf;
int pf,markpf,n;
double rhoc;

if((inf=fopen(EOSname,"r"))==NULL)
{
printf("\nfile not found!\n");
fprintf(scanlog,"\nfile not found!\n");
return 0;
}
while(fscanf(inf,"%lf",&EOS_lgrho[length_EOS])==1)
{
fscanf(inf,"%lf",&EOS_lgp[length_EOS]);
length_EOS++;
}
rho_core=pow(10,EOS_lgrho[length_EOS-1]);

for(n=0;n<length_EOS;n++)
{
EOS_lgrho[n]=EOS_lgrho[n]-10.175607290470733;
EOS_lgp[n]=EOS_lgp[n]-27.129849799910058;
}
p_surf=pow(10,EOS_lgp[0]);

int cnt=0,nlength=strlen(EOSname);
char outname[60];
for(n=nlength;n>nlength-5;n--)
{
EOSname[n]='\0';
}
sprintf(outname,"%c%c%s%c%s%s%s",'.','\\',sT,'\\',"outf_",EOSname,".dat");
outf=fopen(outname,"w");
printf("\n[Manual Mode]: %s EoS is processing\n", EOSname);
fprintf(scanlog,"\n[Manual Mode]: %s EoS is processing\n", EOSname);

pf=0;
rhoc=1e18;
fprintf(scanlog,"\n\t%-15s\t%-10s\t%-10s\t%-10s\n","rhoc/(kg.m-3)","M/Msun","R/km","k2");
for(pf=0;;pf++)
{
printf("\nEnter a central density (0 for exit): ");
fflush(stdin);scanf("%lf",&rhoc);
if(rhoc<1e13) break;
getRM(rhoc);
printf("\t%-15s\t%-10s\t%-10s\t%-10s\n","rhoc/(kg.m-3)","M/Msun","R/km","k2");
printf("\t%-15e\t%-10f\t%-10f\t%-10f\n",rhoc,temp_M,temp_R,temp_k2);
fprintf(scanlog,"\t%-15e\t%-10f\t%-10f\t%-10f\n",rhoc,temp_M,temp_R,temp_k2);
fprintf(outf,"%e            %f            %f            %f\n",rhoc,temp_M,temp_R,temp_k2);
}
fclose(outf);
return 0;
}

int ManualC(EOSname)
char EOSname[50];
{
FILE *inf,*outf;
double sden,eden,rhoc=1e18,dstep;
int pf,markpf,n;

if((inf=fopen(EOSname,"r"))==NULL)
{
printf("\nfile not found!\n");
fprintf(scanlog,"\nfile not found!\n");
return 0;
}
while(fscanf(inf,"%lf",&EOS_lgrho[length_EOS])==1)
{
fscanf(inf,"%lf",&EOS_lgp[length_EOS]);
length_EOS++;
}
rho_core=pow(10,EOS_lgrho[length_EOS-1]);

for(n=0;n<length_EOS;n++)
{
EOS_lgrho[n]=EOS_lgrho[n]-10.175607290470733;
EOS_lgp[n]=EOS_lgp[n]-27.129849799910058;
}
p_surf=pow(10,EOS_lgp[0]);

int cnt=0,nlength=strlen(EOSname);
char outname[60];
for(n=nlength;n>nlength-5;n--)
{
EOSname[n]='\0';
}
sprintf(outname,"%c%c%s%c%s%s%s",'.','\\',sT,'\\',"outf_",EOSname,".dat");
outf=fopen(outname,"w");
printf("[Manual Mode]: %s EoS is processing\n", EOSname);
fprintf(scanlog,"[Manual Mode]: %s EoS is processing\n", EOSname);

pf=0;
printf("Enter STARTpoint of central density: ");
fprintf(scanlog,"\nEnter STARTpoint of central density: \n");
fflush(stdin);scanf("%lf",&sden);
printf("Enter ENDpoint of central density: ");
fprintf(scanlog,"\nEnter ENDpoint of central density: \n");
fflush(stdin);scanf("%lf",&eden);
if((eden<1e12)||(eden>5e18)||(sden<1e12)||(sden>5e18))
{
	printf("Warning: wrong inputs.\n");
	fprintf(scanlog,"Warning: wrong inputs.\n");
	fclose(outf);
	return 0;
}
printf("\t%-15s\t%-10s\t%-10s\t%-10s\n","rhoc/(kg.m-3)","M/Msun","R/km","k2");
fprintf(scanlog,"\n\t%-15s\t%-10s\t%-10s\t%-10s\n","rhoc/(kg.m-3)","M/Msun","R/km","k2");
if(sden==eden)
{
	getRM(sden);
	printf("\t%-15e\t%-10f\t%-10f\t%-10f\n",sden,temp_M,temp_R,temp_k2);
    fprintf(scanlog,"\t%-15e\t%-10f\t%-10f\t%-10f\n",sden,temp_M,temp_R,temp_k2);
	fprintf(outf,"%e            %f            %f            %f\n",sden,temp_M,temp_R,temp_k2);
}else{
	dstep=(eden-sden)*0.03125;
	pf=-1;
for(rhoc=sden;pf<32;rhoc=rhoc+dstep)
{
	pf++;
getRM(rhoc);
printf("\t%-15e\t%-10f\t%-10f\t%-10f\n",rhoc,temp_M,temp_R,temp_k2);
fprintf(scanlog,"\t%-15e\t%-10f\t%-10f\t%-10f\n",rhoc,temp_M,temp_R,temp_k2);
fprintf(outf,"%e            %f            %f            %f\n",rhoc,temp_M,temp_R,temp_k2);
}
}
fclose(outf);
return 0;
}


int Scan(EOSname)
char EOSname[50];
{
FILE *inf,*outf;
double profile_rhoc[300],profile_R[300],profile_M[300],profile_k2[300];
int pf,markpf,n;

if((inf=fopen(EOSname,"r"))==NULL)
{
printf("\nfile not found!\n");
fprintf(scanlog,"\nfile not found!\n");
return 0;
}
while(fscanf(inf,"%lf",&EOS_lgrho[length_EOS])==1)
{
fscanf(inf,"%lf",&EOS_lgp[length_EOS]);
length_EOS++;
}
rho_core=pow(10,EOS_lgrho[length_EOS-1]);

for(n=0;n<length_EOS;n++)
{
EOS_lgrho[n]=EOS_lgrho[n]-10.175607290470733;
EOS_lgp[n]=EOS_lgp[n]-27.129849799910058;
}
p_surf=pow(10,EOS_lgp[0]);

pf=0;
profile_rhoc[pf]=9e17;
getRM(profile_rhoc[pf]);
profile_R[pf]=temp_R;
profile_M[pf]=temp_M;
profile_k2[pf]=temp_k2;
pf++;
profile_rhoc[pf]=9.2e17;
getRM(profile_rhoc[pf]);
profile_R[pf]=temp_R;
profile_M[pf]=temp_M;
profile_k2[pf]=temp_k2;

if((profile_R[0]<23.6)&&(profile_R[0]>6.7)&&(profile_M[0]>0.2)&&(profile_M[0]<3))
{
}else{
printf("\n\n     Unexpected errors occur when generating startpoint of %s\n",EOSname);
fprintf(scanlog,"\n\n     Unexpected errors occur when generating startpoint of %s\n",EOSname);
return 0;
}

while(pf<200)
{
if(profile_rhoc[pf]>=rho_core)
{
//printf("Warning:EoS out of range!\n");
break;
}
if((profile_M[pf]-profile_M[pf-1]<0.01)&&(profile_M[pf]-profile_M[pf-1]>0))
{
pf++;
profile_rhoc[pf]=3*profile_rhoc[pf-1]-2*profile_rhoc[pf-2];
getRM(profile_rhoc[pf]);
profile_R[pf]=temp_R;
profile_M[pf]=temp_M;
profile_k2[pf]=temp_k2;
}else if(profile_M[pf]-profile_M[pf-1]<0.05){
pf++;
profile_rhoc[pf]=2*profile_rhoc[pf-1]-profile_rhoc[pf-2];
getRM(profile_rhoc[pf]);
profile_R[pf]=temp_R;
profile_M[pf]=temp_M;
profile_k2[pf]=temp_k2;
}else{
pf++;
profile_rhoc[pf]=profile_rhoc[pf-1];
profile_R[pf]=profile_R[pf-1];
profile_M[pf]=profile_M[pf-1];
profile_k2[pf]=profile_k2[pf-1];
profile_rhoc[pf-1]=0.618*profile_rhoc[pf-2]+0.382*profile_rhoc[pf];
getRM(profile_rhoc[pf-1]);
profile_R[pf-1]=temp_R;
profile_M[pf-1]=temp_M;
profile_k2[pf-1]=temp_k2;
}
if(profile_M[pf]<=profile_M[pf-1])
{
pf++;
profile_rhoc[pf]=profile_rhoc[pf-1];
profile_R[pf]=profile_R[pf-1];
profile_M[pf]=profile_M[pf-1];
profile_k2[pf]=profile_k2[pf-1];
profile_rhoc[pf-1]=0.618*profile_rhoc[pf-2]+0.382*profile_rhoc[pf];
getRM(profile_rhoc[pf-1]);
profile_R[pf-1]=temp_R;
profile_M[pf-1]=temp_M;
profile_k2[pf-1]=temp_k2;
break;
}
}

markpf=pf;
pf++;
profile_rhoc[pf]=profile_rhoc[1];
profile_R[pf]=profile_R[1];
profile_M[pf]=profile_M[1];
profile_k2[pf]=profile_k2[1];
pf++;
profile_rhoc[pf]=profile_rhoc[0];
profile_R[pf]=profile_R[0];
profile_M[pf]=profile_M[0];
profile_k2[pf]=profile_k2[0];
while(pf<300)
{
if((Abs(profile_R[pf-1]-profile_R[pf])<0.04)&&(profile_M[pf-1]-profile_M[pf]<0.01))
{
pf++;
profile_rhoc[pf]=3*profile_rhoc[pf-1]-2*profile_rhoc[pf-2];
getRM(profile_rhoc[pf]);
profile_R[pf]=temp_R;
profile_M[pf]=temp_M;
profile_k2[pf]=temp_k2;
}else if((Abs(profile_R[pf-1]-profile_R[pf])<0.2)&&(profile_M[pf-1]-profile_M[pf])<0.03){
pf++;
profile_rhoc[pf]=2*profile_rhoc[pf-1]-profile_rhoc[pf-2];
getRM(profile_rhoc[pf]);
profile_R[pf]=temp_R;
profile_M[pf]=temp_M;
profile_k2[pf]=temp_k2;
}else{
pf++;
profile_rhoc[pf]=profile_rhoc[pf-1];
profile_R[pf]=profile_R[pf-1];
profile_M[pf]=profile_M[pf-1];
profile_k2[pf]=profile_k2[pf-1];
profile_rhoc[pf-1]=0.5*profile_rhoc[pf-2]+0.5*profile_rhoc[pf];
getRM(profile_rhoc[pf-1]);
profile_R[pf-1]=temp_R;
profile_M[pf-1]=temp_M;
profile_k2[pf-1]=temp_k2;
}
if((profile_R[pf]>23.6)||(profile_M[pf]<0.18)) break;
}

int cnt=0,nlength=strlen(EOSname);
char outname[60];
for(n=nlength;n>nlength-5;n--)
{
EOSname[n]='\0';
}
sprintf(outname,"%c%c%s%c%s%s%s",'.','\\',sT,'\\',"outf_",EOSname,".dat");

outf=fopen(outname,"w");

for(n=pf;n>markpf;n--)
{
fprintf(outf,"%e            %f            %f            %f\n",profile_rhoc[n],profile_M[n],profile_R[n],profile_k2[n]);cnt++;
}
for(n=0;n<markpf+1;n++)
{
if(profile_rhoc[n]>profile_rhoc[markpf+1])
{
fprintf(outf,"%e            %f            %f            %f\n",profile_rhoc[n],profile_M[n],profile_R[n],profile_k2[n]);cnt++;
}
}

fclose(outf);

double x1=profile_R[markpf],y1=profile_M[markpf],x2=profile_R[markpf-1],y2=profile_M[markpf-1],x3=profile_R[markpf-2],y3=profile_M[markpf-2];
double LA=y1/(x1-x2)/(x1-x3)-y2/(x1-x2)/(x2-x3)+y3/(x1-x3)/(x2-x3),LB=-y1*(x2+x3)/(x1-x2)/(x1-x3)+y2*(x1+x3)/(x1-x2)/(x2-x3)-y3*(x1+x2)/(x1-x3)/(x2-x3),LC=y1*x2*x3/(x1-x2)/(x1-x3)-y2*x1*x3/(x1-x2)/(x2-x3)+y3*x1*x2/(x1-x3)/(x2-x3);
double Mmax=LC-0.25*LB*LB/LA;
printf("\n       %s\t%f\t%d\n",EOSname,Mmax,cnt);
fprintf(scanlog,"\n       %s\t%f\t%d\n",EOSname,Mmax,cnt);
for(n=0;n<length_EOS;n++){
EOS_lgrho[n]='\0';
EOS_lgp[n]='\0';
}
length_EOS=0,loopTOV=1;
return 0;
}

int main()
{
FILE *mdir;
char tpEOS[50],decklog[50];
int n=0,k=0,mode;
time_t timep;
struct tm *p;
time(&timep);
p=gmtime(&timep);
sprintf(sT,"%s%d%d%d%d%d%d","Results_",1900+p->tm_year,1+p->tm_mon,p->tm_mday,8+p->tm_hour,p->tm_min,p->tm_sec);
sprintf(decklog,"%c%c%s%c%s",'.','\\',sT,'\\',"ScreenRecord.log");
system("title Auto Scanning Radius Mass by Chan --- ver 3.2    for Windows");
printf("\nPlease ensure only EoS files at root path are *.txt files before scanning\n(but no need to worry about readme.txt)\n\nPress any key to START scanning process\n");
system("pause");
mkdir(sT);
scanlog=fopen(decklog,"a");
mdir=fopen("temp_dir.dat","w");
fclose(mdir);
system("dir *.txt /B /A-R /ON >> temp_dir.dat");
if((mdir=fopen("temp_dir.dat","r"))==NULL){
printf("\nNo EoS *.txt files detected, press any key to exit..");
fclose(scanlog);
system("pause");
return 0;
}

printf("\n\nSelect a Central Densities mode:\t\n[0]\tManual Mode S (tests a specific point each time)\t\n[1]\tManual Mode C (give startpoint and endpoint to scan)\t\n[2]\tAutomatical Mode (auto scanning for rough M-R curves)\n\nEnter a Mode serial number: ");
fflush(stdin);scanf("%d",&mode);

if(mode==0)
{
	while(fscanf(mdir,"%s",tpEOS)>0)
	{
		k++;
		ManualS(tpEOS);
		for(n=0;n<50;n++)
		{
			tpEOS[n]='\0';
		}
	}
}else if(mode==1){
	while(fscanf(mdir,"%s",tpEOS)>0)
	{
		k++;
		ManualC(tpEOS);
		for(n=0;n<50;n++)
		{
			tpEOS[n]='\0';
		}
	}
}else{
printf("\nExecuting scanning process..\n\n       EoS\tMmax(Msun)\tEffective Points\n");
fprintf(scanlog,"\nExecuting scanning process..\n\n       EoS\tMmax(Msun)\tEffective Points\n");
while(fscanf(mdir,"%s",tpEOS)>0)
{
k++;
Scan(tpEOS);
for(n=0;n<50;n++)
{
tpEOS[n]='\0';
}
}
}

fclose(mdir);
remove("temp_dir.dat");
printf("\n\nScanning process has finished, %d available results are saved separately.\n\n(e.g. Results for [EoS_L32.txt] would be saved as [outf_EoS_L32.dat])\n\nPress any key to left\n",k);
fprintf(scanlog,"\n\nScanning process has finished, %d available results are saved separately.\n\n(e.g. Results for [EoS_L32.txt] would be saved as [outf_EoS_L32.dat])\n\nPress any key to left\n",k);
fclose(scanlog);
system("pause");
return 0;
}