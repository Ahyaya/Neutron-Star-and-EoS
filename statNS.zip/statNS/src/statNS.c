/*	Good news, I reconstruct the code for TOV equation computation.
*
*	Fixed Mass Neutron Star configuration probe
*
*	remix version, please notice that the source code has been completely out of date.
*
*	this code is tested on CentOS-8 with gcc 10.3.1
*
*	Contact: c.houyuan@mail.scut.edu.cn
*
*	or you can leave your comment on my website:
*	https://arxiv.cloud/
*
*/

#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define pi 3.14159265358979
#define Mscale 2.033931261665867e5
#define c 2.99792458e8

struct EoS_t {
	int length;
	double RhomaxSI;
	double Rhomax;
	double Rhomin;
	double Pmax;
	double Pmin;
	double Mmax;
	double Rhoc_MmaxSI;
	double lgRho[3000];
	double lgP[3000];
	char FilePath[128];
} EoS;

struct CompactStar_t {
	double P;
	double r;
	double Rho;
	double M;
	double Ma;
	double Mp;
	double I;
	double Ag00;
	double y;
	double k2;
	double Lambda;
	double Vs;
} nsVar;

struct RungeKutta_Array_t {
	double P;
	double M;
	double I;
	double Ag00;
	double y;
} rkVar;

struct ComputeStatus_t {
	int RkStop;
	int AllStop;
	double RkErr;
	int (*K_roll)(struct RungeKutta_Array_t *K, double h, double r, struct RungeKutta_Array_t *X);
	int (*X_join)(struct RungeKutta_Array_t *Result, double h, struct RungeKutta_Array_t *K);
} ComputeStatus={0};

int dFunc(struct RungeKutta_Array_t *K, double r, struct RungeKutta_Array_t *X);

double interp_p2rho(double cp);
double interp_rho2p(double crho);
int RungeKutta_Array_add (struct RungeKutta_Array_t *Result, double h, struct RungeKutta_Array_t *K, struct RungeKutta_Array_t *X);
int RungeKutta_Array_adds (struct RungeKutta_Array_t *Result, double *h, struct RungeKutta_Array_t *K, struct RungeKutta_Array_t *X, int dim);

/*
*	The TOV equation's ODE expression is defined here.
*	K has the meaning of first derivative, so K->M is
*	equivalent to dM/dr.
*	You will know what to do if you're familiar with the TOV equation.
*/
int dFunc(struct RungeKutta_Array_t *K, double r, struct RungeKutta_Array_t *X){
	double Rho=interp_p2rho(X->P);
	double Vs=nsVar.Vs;
	K->M = 4.0*pi*Rho*r*r;
	K->P = (Rho+X->P)*(X->M+4*pi*r*r*r*(X->P))/(2*(X->M)*r-r*r);
	K->I = 8.0/3*pi*r*r*r*r*(Rho+X->P)/sqrt(1-2*(X->M)/r)/sqrt(X->Ag00);
	K->Ag00 = -2*(X->Ag00)*(K->P)/(Rho+X->P);
	K->y=-(X->y)*(X->y)/r-(X->y)/r*(1+4.0*pi*r*r*(X->P-Rho))/(1-2*(X->M)/r)-r*(4*pi*(5*Rho+9*(X->P)+(X->P+Rho)/Vs)/(1-2*(X->M)/r)-6/r/r/(1-2*(X->M)/r)-4/r/r/r/r/(1-2*(X->M)/r)/(1-2*(X->M)/r)*(X->M+4*pi*r*r*r*(X->P))*(X->M+4*pi*r*r*r*(X->P)));
	return 0;
}

/*===========================================
*	default propagator RK4, classic and stable (without error control)
*/
int RungeKutta_RK4_roll(struct RungeKutta_Array_t *K, double h, double r, struct RungeKutta_Array_t *X){
	dFunc(&K[0], r, X);
	RungeKutta_Array_add(&rkVar, h/2, &K[0], X);
	dFunc(&K[1], r+h/2, &rkVar);
	RungeKutta_Array_add(&rkVar, h/2, &K[1], X);
	dFunc(&K[2], r+h/2, &rkVar);
	RungeKutta_Array_add(&rkVar, h, &K[2], X);
	dFunc(&K[3], r+h, &rkVar);
	return 0;
}

int RungeKutta_RK4_join (struct RungeKutta_Array_t *Result, double h, struct RungeKutta_Array_t *K) {
	Result->P += h/6*(K[0].P+2*(K[1].P)+2*(K[2].P)+K[3].P);
	Result->M += h/6*(K[0].M+2*(K[1].M)+2*(K[2].M)+K[3].M);
	Result->I += h/6*(K[0].I+2*(K[1].I)+2*(K[2].I)+K[3].I);
	Result->y += h/6*(K[0].y+2*(K[1].y)+2*(K[2].y)+K[3].y);
	Result->Ag00 += h/6*(K[0].Ag00+2*(K[1].Ag00)+2*(K[2].Ag00)+K[3].Ag00);
	return 0;
}
/*pair tools of RK4
===========================================*/


/*===========================================
*	embedded propagator RK4M, classic and stable with error control
*/
int RungeKutta_RK4M_roll(struct RungeKutta_Array_t *K, double h, double r, struct RungeKutta_Array_t *X){
	double H_1[1]={h/2};
	double H_2[2]={0,h/2};
	double H_2M[2]={-h,2*h};
	double H_3[3]={0,0,h};
	dFunc(&K[0], r, X);
	RungeKutta_Array_adds(&rkVar, H_1, K, X,1);
	dFunc(&K[1], r+h/2, &rkVar);
	RungeKutta_Array_adds(&rkVar, H_2, K, X,2);
	dFunc(&K[2], r+h/2, &rkVar);
	RungeKutta_Array_adds(&rkVar, H_3, K, X,3);
	dFunc(&K[3], r+h, &rkVar);
	RungeKutta_Array_adds(&rkVar,H_2M,K,X,2);
	dFunc(&K[4], r+h, &rkVar);
	return 0;
}

int RungeKutta_RK4M_join (struct RungeKutta_Array_t *Result, double h, struct RungeKutta_Array_t *K) {
	Result->P += h/6*(K[0].P+2*(K[1].P)+2*(K[2].P)+K[3].P);
	Result->M += h/6*(K[0].M+2*(K[1].M)+2*(K[2].M)+K[3].M);
	Result->I += h/6*(K[0].I+2*(K[1].I)+2*(K[2].I)+K[3].I);
	Result->y += h/6*(K[0].y+2*(K[1].y)+2*(K[2].y)+K[3].y);
	Result->Ag00 += h/6*(K[0].Ag00+2*(K[1].Ag00)+2*(K[2].Ag00)+K[3].Ag00);
	ComputeStatus.RkErr=(-2*(K[1].P)+2*(K[2].P)+(K[3].P)-(K[4].P))/(K[0].P+2*(K[1].P)+2*(K[2].P)+K[3].P);
	ComputeStatus.RkErr=ComputeStatus.RkErr>0?ComputeStatus.RkErr:(-ComputeStatus.RkErr);
	return 0;
}
/*pair tools of RK4M
===========================================*/


/*===========================================
*	Runge-Kutta-Fehlberg method RK5F, high precision with error control (not tested)
*/
int RungeKutta_RK5F_roll(struct RungeKutta_Array_t *K, double h, double r, struct RungeKutta_Array_t *X){
	double H_1[1]={0.25*h};
	double H_2[2]={0.093750*h,0.281250*h};
	double H_3[3]={1932.0*h/2179,-7200.0*h/2179,7296.0*h/2179};
	double H_4[4]={439.0*h/216,-8*h,3680.0*h/513,-845.0*h/4104};
	double H_5[5]={-8.0*h/27,2*h,-3544.0*h/2565,1859.0*h/4104,-11.0*h/40};
	dFunc(&K[0], r, X);
	RungeKutta_Array_adds(&rkVar,H_1,K,X,1);
	dFunc(&K[1], r+0.25*h, &rkVar);
	RungeKutta_Array_adds(&rkVar,H_2,K,X,2);
	dFunc(&K[2], r+0.375*h, &rkVar);
	RungeKutta_Array_adds(&rkVar,H_3,K,X,3);
	dFunc(&K[3], r+12.0*h/13, &rkVar);
	RungeKutta_Array_adds(&rkVar,H_4,K,X,4);
	dFunc(&K[4], r+h, &rkVar);
	RungeKutta_Array_adds(&rkVar,H_5,K,X,5);
	dFunc(&K[5], r+0.5*h, &rkVar);
	return 0;
}

int RungeKutta_RK5F_join (struct RungeKutta_Array_t *Result, double h, struct RungeKutta_Array_t *K) {
	Result->P += h*(16.0/135*(K[0].P) + 6656.0/12825*(K[2].P) + 28561.0/56430*(K[3].P) - 0.18*(K[4].P) + 2.0/55*(K[5].P) );
	Result->M += h*(16.0/135*(K[0].M) + 6656.0/12825*(K[2].M) + 28561.0/56430*(K[3].M) - 0.18*(K[4].M) + 2.0/55*(K[5].M) );
	Result->I += h*(16.0/135*(K[0].I) + 6656.0/12825*(K[2].I) + 28561.0/56430*(K[3].I) - 0.18*(K[4].I) + 2.0/55*(K[5].I) );
	Result->y += h*(16.0/135*(K[0].y) + 6656.0/12825*(K[2].y) + 28561.0/56430*(K[3].y) - 0.18*(K[4].y) + 2.0/55*(K[5].y) );
	Result->Ag00 += h*(16.0/135*(K[0].Ag00) + 6656.0/12825*(K[2].Ag00) + 28561.0/56430*(K[3].Ag00) - 0.18*(K[4].Ag00) + 2.0/55*(K[5].Ag00) );
	ComputeStatus.RkErr=(0.0027778*(K[0].P) - 0.0299415*(K[2].P)  - 0.0291999*(K[3].P) + 0.0200000*(K[4].P) +  0.0363636*(K[5].P))/(16.0/135*(K[0].P) + 6656.0/12825*(K[2].P) + 28561.0/56430*(K[3].P) - 0.18*(K[4].P) + 2.0/55*(K[5].P) );
	ComputeStatus.RkErr=ComputeStatus.RkErr>0?ComputeStatus.RkErr:(-ComputeStatus.RkErr);
	return 0;
}
/*pair tools of RK5F
===========================================*/


/*===========================================
*	Dormand-Prince method RK5M, high precision with error control (tested)
*	published at https://www.sciencedirect.com/science/article/pii/0771050X80900133
*/
int RungeKutta_RK5M_roll(struct RungeKutta_Array_t *K, double h, double r, struct RungeKutta_Array_t *X){
	double H_1[1]={0.2*h};
	double H_2[2]={0.075000*h,0.225000*h};
	double H_3[3]={0.3*h,-0.9*h,1.2*h};
	double H_4[4]={226.0/729*h,-25.0/27*h,880.0/729*h,55.0/729*h};
	double H_5[5]={-181.0/270*h,2.5*h,-266.0/297*h,-91.0/27*h,189.0/55*h};
	dFunc(&K[0], r, X);
	RungeKutta_Array_adds(&rkVar,H_1,K,X,1);
	dFunc(&K[1], r+0.2*h, &rkVar);
	RungeKutta_Array_adds(&rkVar,H_2,K,X,2);
	dFunc(&K[2], r+0.3*h, &rkVar);
	RungeKutta_Array_adds(&rkVar,H_3,K,X,3);
	dFunc(&K[3], r+0.6*h, &rkVar);
	RungeKutta_Array_adds(&rkVar,H_4,K,X,4);
	dFunc(&K[4], r+2.0*h/3, &rkVar);
	RungeKutta_Array_adds(&rkVar,H_5,K,X,5);
	dFunc(&K[5], r+h, &rkVar);
	return 0;
}

int RungeKutta_RK5M_join (struct RungeKutta_Array_t *Result, double h, struct RungeKutta_Array_t *K) {
	Result->P += h*(31.0/540*(K[0].P) + 190.0/297*(K[2].P) - 145.0/108*(K[3].P) + 351.0/220*(K[4].P) + 0.05*(K[5].P) );
	Result->M += h*(31.0/540*(K[0].M) + 190.0/297*(K[2].M) - 145.0/108*(K[3].M) + 351.0/220*(K[4].M) + 0.05*(K[5].M) );
	Result->I += h*(31.0/540*(K[0].I) + 190.0/297*(K[2].I) - 145.0/108*(K[3].I) + 351.0/220*(K[4].I) + 0.05*(K[5].I) );
	Result->y += h*(31.0/540*(K[0].y) + 190.0/297*(K[2].y) - 145.0/108*(K[3].y) + 351.0/220*(K[4].y) + 0.05*(K[5].y) );
	Result->Ag00 += h*(31.0/540*(K[0].Ag00) + 190.0/297*(K[2].Ag00) - 145.0/108*(K[3].Ag00) + 351.0/220*(K[4].Ag00) + 0.05*(K[5].Ag00) );
	ComputeStatus.RkErr=(-0.030556*(K[0].P) + 0.158730*(K[2].P)  - 0.763889*(K[3].P) + 0.675000*(K[4].P) - 0.039286*(K[5].P))/(31.0/540*(K[0].P) + 190.0/297*(K[2].P) - 145.0/108*(K[3].P) + 351.0/220*(K[4].P) + 0.05*(K[5].P) );
	ComputeStatus.RkErr=ComputeStatus.RkErr>0?ComputeStatus.RkErr:(-ComputeStatus.RkErr);
	return 0;
}
/*pair tools of RK5M
===========================================*/


/*
*	efficient solver to compute TOV equation, 
*	a great balance between speed and accuracy,
*	which is adjusted from stdTOV()
*/
double solveTOV(double RhocSI) {
	/*clear the stop mark*/
	ComputeStatus.RkStop=0;

	/*decide which paprogator to use to solve the TOV equation*/
	ComputeStatus.K_roll=RungeKutta_RK5M_roll;
	ComputeStatus.X_join=RungeKutta_RK5M_join;
	/*the roll and join must be in pair*/
	
	struct RungeKutta_Array_t K[8];
	double h;

	double rho=RhocSI*6.6741e-11, r=0.125/c, r_offset;
	double m=4.0/3*r*r*r*rho, p=interp_rho2p(rho), y=2.0, I=0.0, Ag00=1.0;
	int pf=0;
	struct RungeKutta_Array_t X={p,m,I,Ag00,y};

	/*core section with proceeding stepsize*/
	h=0.125/c;
	for(pf=0;pf<64;pf++) {
		ComputeStatus.K_roll(K, h, r, &X);
		if(ComputeStatus.RkStop) break;
		ComputeStatus.X_join(&X,h, K);
		r+=h;
	}
	h=1.0/c;
	for(pf=0;pf<128;pf++) {
		ComputeStatus.K_roll(K, h, r, &X);
		if(ComputeStatus.RkStop) break;
		ComputeStatus.X_join(&X,h, K);
		r+=h;
	}
	h=4.0/c;
	for(pf=0;pf<256;pf++) {
		ComputeStatus.K_roll(K, h, r, &X);
		if(ComputeStatus.RkStop) break;
		ComputeStatus.X_join(&X,h, K);
		r+=h;
	}
	/*end of core section*/

	/*regular computation*/
	h=16.0/c;
	while(r<1e-4) {
		ComputeStatus.K_roll(K, h, r, &X);
		if(ComputeStatus.RkStop) break;
		ComputeStatus.X_join(&X,h, K);
		r+=h;
	}
	if(!ComputeStatus.RkStop){
		fprintf(stderr,"error while computing density: %.5e\n",RhocSI);
		return 0;
	}
	/*Generally, the computation would be interrupted by ComputeStatus.RkStop==1,
	if it doesn't work the solver will exit without changing the content of nsVar.*/

	/*use a small stepsize to reach the surface*/
	ComputeStatus.RkStop=0;
	h=2.0/c;
	while(1) {
		ComputeStatus.K_roll(K, h, r, &X);
		if(ComputeStatus.RkStop) break;
		ComputeStatus.X_join(&X,h, K);
		r+=h;
	}
	/*interpolate the radius at surface, according to pressure and its derivative*/
	r_offset=K[0].P<0?X.P/(K[0].P):0;
	r_offset=r_offset>-h?r_offset:-h;
	r-=r_offset;

	m=X.M;
	I=X.I;
	y=X.y;
	p=X.P;
	Ag00=X.Ag00;

	double bt=m/r;
	double Bg00=(1-2.0*m/r)/Ag00;
	nsVar.I=I/(m*r*r*sqrt(Bg00));
	nsVar.r=r*c*1e-3;
	nsVar.M=m*Mscale;
	nsVar.k2=1.6*bt*bt*bt*bt*bt*(1-2*bt)*(1-2*bt)*(2-y+2*bt*(y-1))/(2*bt*(6-3*y+3*bt*(5*y-8))+4*bt*bt*bt*(13-11*y+bt*(3*y-2)+2*bt*bt*(1+y))+3*(1-2*bt)*(1-2*bt)*(2-y+2*bt*(y-1))*log(1-2*bt));
	nsVar.Lambda=9495*nsVar.k2*pow(nsVar.r/10,5)/pow(nsVar.M,5);

	return(m*Mscale);
}

/*
*	stdTOV() is being tested within multiple scenarios,
*	She's slow somehow, but she could be used as reference 
*	for debug or precise computation
*/
double stdTOV(double RhocSI) {
	ComputeStatus.RkStop=0;
	struct RungeKutta_Array_t K[8];
	double h=0.025/c;
	/*h is step-size in GI units where h=1 refers to 3e+8 meters.*/

	double rho=RhocSI*6.6741e-11, r=h;
	double m=4.0/3*r*r*r*rho, p=interp_rho2p(rho), y=2.0, I=0.0, Ag00=1.0;
	int pf=0;
	struct RungeKutta_Array_t X={p,m,I,Ag00,y};

	while(r<1e-4) {
		RungeKutta_RK4_roll(K, h, r, &X);
		if(ComputeStatus.RkStop) break;
		RungeKutta_RK4_join(&X,h, K);
		r+=h;
	}
	m=X.M;
	I=X.I;
	y=X.y;
	p=X.P;
	Ag00=X.Ag00;
	double bt=m/r;
	double Bg00=(1-2.0*m/r)/Ag00;
	nsVar.I=I/(m*r*r*sqrt(Bg00));
	nsVar.r=r*c*1e-3;
	nsVar.M=m*Mscale;
	nsVar.k2=1.6*bt*bt*bt*bt*bt*(1-2*bt)*(1-2*bt)*(2-y+2*bt*(y-1))/(2*bt*(6-3*y+3*bt*(5*y-8))+4*bt*bt*bt*(13-11*y+bt*(3*y-2)+2*bt*bt*(1+y))+3*(1-2*bt)*(1-2*bt)*(2-y+2*bt*(y-1))*log(1-2*bt));
	nsVar.Lambda=9495*nsVar.k2*pow(nsVar.r/10,5)/pow(nsVar.M,5);
	return(m*Mscale);
}

/*
*	Compute the maximum mass for the loaded EoS.
*/
double getMmax() {
	int n;
	double m0,m1,ma,mb,mc,md,E0,E1,Ea,Eb,Ec,Ed,Mmax,dE=1e12;

	E1=(EoS.RhomaxSI<4.2e18)?EoS.RhomaxSI:4.2e18;
	E0=E1-dE;
	m1=solveTOV(E1);m0=solveTOV(E0);
	if(m0-m1<=0) {
		EoS.Rhoc_MmaxSI=E1;
		EoS.Mmax=m1;
		goto getMmaxRTB;
	}
	for(n=0;n<7;n++) {
		E1=E1*0.72;
		E0=E1-dE;
		m1=solveTOV(E1);m0=solveTOV(E0);
		if(m0-m1<=0) break;
	}
	if(m0-m1>0) {
		EoS.Rhoc_MmaxSI=E0;
		EoS.Mmax=m0;
		goto getMmaxRTB;
	}
	Ea=E1;Eb=E1*1.3888888889;
	Ec=Ea+0.382*(Eb-Ea);
	Ed=Eb-Ec+Ea;
	mc=solveTOV(Ec);md=solveTOV(Ed);
	for(n=0;n<15;n++) {
		if(mc-md>0) {
			Eb=Ed;mb=md;
			Ed=Ec;md=mc;
			Ec=Ea+0.382*(Eb-Ea);
			mc=solveTOV(Ec);
		}else{
			Ea=Ec;ma=mc;
			Ec=Ed;mc=md;
			Ed=Ea+0.618*(Eb-Ea);
			md=solveTOV(Ed);
		}
	}
	EoS.Rhoc_MmaxSI=(mc-md>0)?(0.5*(Ea+Ed)):(0.5*(Ec+Eb));
	EoS.Mmax=solveTOV(EoS.Rhoc_MmaxSI);
	getMmaxRTB:
	return(EoS.Mmax);
}

/*
*	Compute the central density when a mass is given,
*	for example, M2Rhoc(1.44) will return a value around 1.2e18 kg/m^3 for APR EoS.
*/
double M2Rhoc(double fM) {
	double Mmax,Mmin,E0,E1,E2,m0,m1,m2;
	int n;
	Mmax=getMmax();
	Mmin=solveTOV(5e17);
	if(Mmax-fM<0) return EoS.Rhoc_MmaxSI;
	if(Mmin>fM) {
		fprintf(stderr,"warning: attempt to find a low mass neutron star!\n");
		return 5e17;
	}
	E0=5e17;E2=EoS.Rhoc_MmaxSI;m0=Mmin;m2=Mmax;
	for(n=0;n<32;n++) {
		E1=0.5*(E0+E2);
		m1=solveTOV(E1);
		if(m1-fM<0)
		{
			E0=E1;m0=m1;
		}else{
			E2=E1;m2=m1;
		}
	}
	return(E0+(E2-E0)*(fM-m0)/(m2-m0));
}

int loadEoS(char *Path) {
	FILE *inf;
	int n;

	if((inf=fopen(Path,"r"))==NULL) {
		fprintf(stderr,"cannot open %s\n",Path);
		return -1;
	}
	sprintf(EoS.FilePath,"%s",Path);
	EoS.length=0;
	while(fscanf(inf,"%lf",&EoS.lgRho[EoS.length])==1) {
		fscanf(inf,"%lf%*[^\n]",&EoS.lgP[EoS.length]);
		EoS.length++;
	}
	fclose(inf);
	EoS.RhomaxSI=pow(10,EoS.lgRho[EoS.length-1]);

/*Convert to natural unit*/
	for(n=0;n<EoS.length;n++) {
		EoS.lgRho[n]=EoS.lgRho[n]-10.175607290470733;
		EoS.lgP[n]=EoS.lgP[n]-27.129849799910058;
	}
	EoS.Pmax=pow(10,EoS.lgP[EoS.length-1]);
	EoS.Pmin=pow(10,EoS.lgP[0]);
	EoS.Rhomax=pow(10,EoS.lgRho[EoS.length-1]);
	EoS.Rhomin=pow(10,EoS.lgRho[0]);
	return 0;
}

/*=================================================================================
*	Main function should be easy to reconstruct according to your own requirement.
*	Currently the main function scan the directory of EoS_lib/ for *.txt format EoS,
*	She will compute the characteristics of the neutron star at the given mass for each EoS.
*─────────────────────────────────────────────────────────────────────────
*─██████──────────██████─██████████████─██████████─██████──────────██████─
*─██░░██████████████░░██─██░░░░░░░░░░██─██░░░░░░██─██░░██████████──██░░██─
*─██░░░░░░░░░░░░░░░░░░██─██░░██████░░██─████░░████─██░░░░░░░░░░██──██░░██─
*─██░░██████░░██████░░██─██░░██──██░░██───██░░██───██░░██████░░██──██░░██─
*─██░░██──██░░██──██░░██─██░░██████░░██───██░░██───██░░██──██░░██──██░░██─
*─██░░██──██░░██──██░░██─██░░░░░░░░░░██───██░░██───██░░██──██░░██──██░░██─
*─██░░██──██████──██░░██─██░░██████░░██───██░░██───██░░██──██░░██──██░░██─
*─██░░██──────────██░░██─██░░██──██░░██───██░░██───██░░██──██░░██████░░██─
*─██░░██──────────██░░██─██░░██──██░░██─████░░████─██░░██──██░░░░░░░░░░██─
*─██░░██──────────██░░██─██░░██──██░░██─██░░░░░░██─██░░██──██████████░░██─
*─██████──────────██████─██████──██████─██████████─██████──────────██████─
*─────────────────────────────────────────────────────────────────────────
*
*	This is a really huge mark to note where the main() is.
*	Don't tell me you can not find it :D
*/
int main(int argc, char *argv[])
{
	FILE *temp;
	int n=0,pf;
	double objM, rhocPre;
	if(argc<2) {
		fprintf(stderr,"usage example: %s 1.44\n",argv[0]);
		return -1;
	}
	temp=fopen(".scanEoS","w");
	fclose(temp);
	system("ls EoS_lib/*.txt > .scanEoS");
	if((temp=fopen(".scanEoS","r"))==NULL) {
		fprintf(stderr, "No Equation of State files detected.\n");fclose(temp);return -1;
	}

	objM=atof(argv[1]);
	n=0;
	while(fscanf(temp,"%s",EoS.FilePath)>0) {
		if(loadEoS(EoS.FilePath)) continue;
		rhocPre=M2Rhoc(objM);
		/*rhocPre=1.224e18;*/
		/*stdTOV(rhocPre);*/

		solveTOV(rhocPre);

		fprintf(stdout,"%s:\n%.5e %.5lf %.5lf %.5e %.5e %.5e\n=============\n",
		EoS.FilePath,
		rhocPre,
		nsVar.r,
		nsVar.M,
		nsVar.k2,
		nsVar.I,
		nsVar.Lambda);

		n++;
	}	
	fclose(temp);
	fprintf(stdout,"\nEoS count: %d\n",n);
	return 0;
}
/*================================================================================
*──────────────────────────────────────────────────────
*─██████████████─██████──────────██████─████████████───
*─██░░░░░░░░░░██─██░░██████████──██░░██─██░░░░░░░░████─
*─██░░██████████─██░░░░░░░░░░██──██░░██─██░░████░░░░██─
*─██░░██─────────██░░██████░░██──██░░██─██░░██──██░░██─
*─██░░██████████─██░░██──██░░██──██░░██─██░░██──██░░██─
*─██░░░░░░░░░░██─██░░██──██░░██──██░░██─██░░██──██░░██─
*─██░░██████████─██░░██──██░░██──██░░██─██░░██──██░░██─
*─██░░██─────────██░░██──██░░██████░░██─██░░██──██░░██─
*─██░░██████████─██░░██──██░░░░░░░░░░██─██░░████░░░░██─
*─██░░░░░░░░░░██─██░░██──██████████░░██─██░░░░░░░░████─
*─██████████████─██████──────────██████─████████████───
*──────────────────────────────────────────────────────	
*	end of main function,
*	That is a really simple use.
=================================================================================*/

/*	Some tool functions which are relatively mathematic are listed as follow,
*	including the linear interpolation between pressure and density, and the
*	RungeKutta_Array_t type matrix's operation.
*/

/*======================================================
*	math for linear interpolation.
*	nsVar.Vs is the square of local speed of sound,
*	which is important for computing love number k2. 
*/
double interp_p2rho(double cp) {
	if(cp<EoS.Pmin) {
		ComputeStatus.RkStop=1;
		return 0;
	}
	double logp=log10(cp),logrho,crho;
	int n=EoS.length-1;
	for(;n>0;n--)
	{
		if(logp>EoS.lgP[n-1])
		{
			logrho=(logp-EoS.lgP[n-1])*(EoS.lgRho[n]-EoS.lgRho[n-1])/(EoS.lgP[n]-EoS.lgP[n-1])+EoS.lgRho[n-1];
			crho=pow(10,logrho);
			/*compute local speed of sound*/
			nsVar.Vs=cp/crho*(EoS.lgP[n]-EoS.lgP[n-1])/(EoS.lgRho[n]-EoS.lgRho[n-1]);
			return(crho);
		}
	}
	fprintf(stderr,"%s interrupted by interp_p2rho(), reason: small P!\n", EoS.FilePath);
	ComputeStatus.RkStop=1;
	return 0;
}

double interp_rho2p(double crho) {
	if(crho<EoS.Rhomin){
		ComputeStatus.RkStop=1;
		return 0;
	}
	double logp,logrho=log10(crho),cp;
	int n=EoS.length-1;
	for(;n>0;n--)
	{
		if(logrho>EoS.lgRho[n-1])
		{
			logp=(logrho-EoS.lgRho[n-1])*(EoS.lgP[n]-EoS.lgP[n-1])/(EoS.lgRho[n]-EoS.lgRho[n-1])+EoS.lgP[n-1];
			cp=pow(10,logp);
			return(cp);
		}
	}
	fprintf(stderr,"%s interrupted by interp_rho2p(), reason: small Rho!\n", EoS.FilePath);
	ComputeStatus.RkStop=1;
	return 0;
}
/*end of interpolation definition
======================================================*/


/*======================================================
*	Array adders are matrix operation function.
*	C language is not good at operating matrix!
*/
int RungeKutta_Array_add (struct RungeKutta_Array_t *Result, double h, struct RungeKutta_Array_t *K, struct RungeKutta_Array_t *X) {
	Result->P=X->P+h*(K->P);
	Result->M=X->M+h*(K->M);
	Result->I=X->I+h*(K->I);
	Result->y=X->y+h*(K->y);
	Result->Ag00=X->Ag00+h*(K->Ag00);
	return 0;
}

int RungeKutta_Array_adds (struct RungeKutta_Array_t *Result, double *h, struct RungeKutta_Array_t *K, struct RungeKutta_Array_t *X, int dim) {
	int pf;
	Result->P=X->P;
	Result->M=X->M;
	Result->I=X->I;
	Result->y=X->y;
	Result->Ag00=X->Ag00;

	for (pf=0;pf<dim;pf++){
		Result->P+=h[pf]*((K+pf)->P);
		Result->M+=h[pf]*((K+pf)->M);
		Result->I+=h[pf]*((K+pf)->I);
		Result->y+=h[pf]*((K+pf)->y);
		Result->Ag00+=h[pf]*((K+pf)->Ag00);
	}
	return 0;
}
/*end of matrix operation function
======================================================*/