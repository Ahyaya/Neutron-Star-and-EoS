Build from source code:
gcc src/statNS.c -lm -o statNS

Example use:
./statNS 1.44

output order?

EoS_path:
central density (kg/m^3), mass (=1.44 for example),love number k2, inertia_momentum (dimension less), Lambda (dimensionless)

