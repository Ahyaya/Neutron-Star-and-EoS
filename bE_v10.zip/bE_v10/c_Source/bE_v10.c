#include<math.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include<direct.h>
#define pi 3.14159265358979
#define Mscale 2.033931261665867e5
#define c 2.99792458e8

FILE *scanlog;
double temp_r,temp_m,temp_ma,temp_mg,temp_p,temp_rho,temp_E,temp_y,temp_cs2,temp_R,temp_M,temp_Ma,temp_Mg,temp_k2,p_surf,E_core,EOS_lgrho[3000],EOS_lgE[3000],EOS_lgp[3000];
int length_EOS=0,loopTOV=1;
char sT[30];

double pchip(cp)
double cp;
{
if(cp<p_surf)
{loopTOV=0;return 0;}

double logp=log10(cp),logE,cE,a0,a1,b0,b1,h0,h1,h2,d0,d1,d2,k0,k1,dydx;
double logrho,drho0,drho1,drho2,krho0,krho1;
int n=length_EOS-1;
int np=n;
for(;n>0;n--)
{
	if(logp>EOS_lgp[n-1])
	{
		if((n>1)&&(n<np))
		{
			h0=EOS_lgp[n-1]-EOS_lgp[n-2];
			h1=EOS_lgp[n]-EOS_lgp[n-1];
			h2=EOS_lgp[n+1]-EOS_lgp[n];
			d0=(EOS_lgE[n-1]-EOS_lgE[n-2])/h0;
			drho0=(EOS_lgrho[n-1]-EOS_lgrho[n-2])/h0;
			d1=(EOS_lgE[n]-EOS_lgE[n-1])/h1;
			drho1=(EOS_lgrho[n]-EOS_lgrho[n-1])/h1;
			d2=(EOS_lgE[n+1]-EOS_lgE[n])/h2;
			drho2=(EOS_lgrho[n+1]-EOS_lgrho[n])/h2;
			k0=3*d0*d1/(d0+d1+(h0*d0+h1*d1)/(h0+h1));
			krho0=3*drho0*drho1/(drho0+drho1+(h0*drho0+h1*drho1)/(h0+h1));
			k1=3*d2*d1/(d2+d1+(h2*d2+h1*d1)/(h2+h1));
			krho1=3*drho2*drho1/(drho2+drho1+(h2*drho2+h1*drho1)/(h2+h1));
		}else if(n==1)
		{
			h1=EOS_lgp[n]-EOS_lgp[n-1];
			h2=EOS_lgp[n+1]-EOS_lgp[n];
			d1=(EOS_lgE[n]-EOS_lgE[n-1])/h1;
			drho1=(EOS_lgrho[n]-EOS_lgrho[n-1])/h1;
			d2=(EOS_lgE[n+1]-EOS_lgE[n])/h2;
			drho2=(EOS_lgrho[n+1]-EOS_lgrho[n])/h2;
			k0=((2*h1+h2)*d1-h1*d2)/(h1+h2);
			krho0=((2*h1+h2)*drho1-h1*drho2)/(h1+h2);
			if(k0*d1<=0)
			{
				k0=0;
			}else if((d1*d2<=0)&&(k0*k0>9*d1*d1))
			{
				k0=3*d1;
			}
			k1=3*d2*d1/(d2+d1+(h2*d2+h1*d1)/(h2+h1));
			if(krho0*drho1<=0)
			{
				krho0=0;
			}else if((drho1*drho2<=0)&&(krho0*krho0>9*drho1*drho1))
			{
				krho0=3*drho1;
			}
			krho1=3*drho2*drho1/(drho2+drho1+(h2*drho2+h1*drho1)/(h2+h1));
		}else if(n==np)
		{
			h0=EOS_lgp[n-1]-EOS_lgp[n-2];
			h1=EOS_lgp[n]-EOS_lgp[n-1];
			d0=(EOS_lgE[n-1]-EOS_lgE[n-2])/h0;
			drho0=(EOS_lgrho[n-1]-EOS_lgrho[n-2])/h0;
			d1=(EOS_lgE[n]-EOS_lgE[n-1])/h1;
			drho1=(EOS_lgrho[n]-EOS_lgrho[n-1])/h1;
			k0=3*d0*d1/(d0+d1+(h0*d0+h1*d1)/(h0+h1));
			krho0=3*drho0*drho1/(drho0+drho1+(h0*drho0+h1*drho1)/(h0+h1));
			k1=((2*h1+h0)*d1-h1*d0)/(h1+h0);
			krho1=((2*h1+h0)*drho1-h1*drho0)/(h1+h0);
			if(k1*d1<=0)
			{
				k1=0;
			}else if((d0*d1<=0)&&(k1*k1>9*d1*d1))
			{
				k1=3*d1;
			}
			if(krho1*drho1<=0)
			{
				krho1=0;
			}else if((drho0*drho1<=0)&&(krho1*krho1>9*drho1*drho1))
			{
				krho1=3*drho1;
			}
		}else
		{
			printf("Warning: pchip error 1\n");
			fprintf(scanlog,"Warning: pchip error 1\n");
			return 0;
		}
		a0=(1+2/h1*(logp-EOS_lgp[n-1]))*(logp-EOS_lgp[n])*(logp-EOS_lgp[n])/h1/h1;
		a1=(1-2/h1*(logp-EOS_lgp[n]))*(logp-EOS_lgp[n-1])*(logp-EOS_lgp[n-1])/h1/h1;
		b0=(logp-EOS_lgp[n-1])*(logp-EOS_lgp[n])*(logp-EOS_lgp[n])/h1/h1;
		b1=(logp-EOS_lgp[n])*(logp-EOS_lgp[n-1])*(logp-EOS_lgp[n-1])/h1/h1;
		logE=a0*EOS_lgE[n-1]+a1*EOS_lgE[n]+k0*b0+k1*b1;
		logrho=a0*EOS_lgrho[n-1]+a1*EOS_lgrho[n]+krho0*b0+krho1*b1;
		cE=pow(10,logE);
		temp_rho=pow(10,logrho);
		dydx=6/h1/h1/h1*(logp-EOS_lgp[n])*(logp-EOS_lgp[n-1])*(EOS_lgE[n-1]-EOS_lgE[n])+k0/h1/h1*(logp-EOS_lgp[n])*(3*logp-EOS_lgp[n]-EOS_lgp[n-1]-EOS_lgp[n-1])+k1/h1/h1*(logp-EOS_lgp[n-1])*(3*logp-EOS_lgp[n-1]-EOS_lgp[n]-EOS_lgp[n]);
		temp_cs2=cp/cE/dydx;
		return(cE);
	}
}
printf("Warning: pchip error 2\n");
fprintf(scanlog,"Warning: pchip error 2\n");
return 0;
}


void fEul(fr,fm,fp,fE,fy,frho,fma,fmg,h)
double fr,fm,fp,fE,fy,frho,fma,fmg,h;
{
temp_r=fr+h;
temp_m=fm+4*pi*fr*fr*fE*h;
temp_ma=fma+4*h*pi*fr*fr*frho/sqrt(1-2*fm/fr);
temp_mg=fmg+4*h*pi*fr*fr*fE/sqrt(1-2*fm/fr);
temp_p=h*(fE+fp)*(fm+4*pi*fr*fr*fr*fp)/(2*fm*fr-fr*fr)+fp;
temp_E=pchip(temp_p);
temp_y=fy+h*(-fy*fy/fr-fy/fr*(1+4*pi*fr*fr*(fp-fE))/(1-2*fm/fr)-fr*(4*pi*(5*fE+9*fp+(fp+fE)/temp_cs2)/(1-2*fm/fr)-6/fr/fr/(1-2*fm/fr)-4/fr/fr/fr/fr/(1-2*fm/fr)/(1-2*fm/fr)*(fm+4*pi*fr*fr*fr*fp)*(fm+4*pi*fr*fr*fr*fp)));
return;
}

double interp_E2p(cE)
double cE;
{
double logp,logE=log10(cE),cp;
int n=length_EOS-1;
for(;n>0;n--)
{
if(logE>EOS_lgE[n-1])
{
logp=(logE-EOS_lgE[n-1])*(EOS_lgp[n]-EOS_lgp[n-1])/(EOS_lgE[n]-EOS_lgE[n-1])+EOS_lgp[n-1];
cp=pow(10,logp);
return(cp);
}
}
printf("Warning:E2p interpolation error\n");
fprintf(scanlog,"Warning:E2p interpolation error\n");
return(0);
}

void getRM(pEc)
double pEc;
{
loopTOV=1;
double fEc=pEc*6.6741e-11;
double h=1e-8,localRes,r,y=2;
double m,ma,mg,p=interp_E2p(fEc),E,rho;
double m11,p11,E11,y11,m21,p21,E21,y21,m22,p22,E22,y22,m31,p31,E31,y31,m61,p61,E61,y61,m62,p62,E62,y62,K_m,K_p,K_E,K_y,A_m,A_p,A_E,A_y,B_m,B_p,B_E,B_y,RK_m,RK_p,RK_E,RK_y,TR_m,TR_p,TR_E,TR_y;
double res1,res2,res3;
double rho11,rho21,rho22,ma11,ma21,ma22,mg11,mg21,mg22,K_rho,K_ma,K_mg,A_rho,A_ma,A_mg,B_rho,B_ma,B_mg,RK_rho,RK_ma,RK_mg;
 
r=h;
pchip(p);
E=temp_E;
rho=temp_rho;
m=4/3*pi*r*r*r*E;
ma=4/3*pi*r*r*r*rho;
mg=m;

while(1)
{
fEul(r,m,p,E,y,rho,ma,mg,h);
m11=temp_m;
p11=temp_p;
E11=temp_E;
y11=temp_y;
rho11=temp_rho;
ma11=temp_ma;
mg11=temp_mg;
fEul(r,m,p,E,y,rho,ma,mg,0.5*h);
m21=temp_m;
p21=temp_p;
E21=temp_E;
y21=temp_y;
rho21=temp_rho;
ma21=temp_ma;
mg21=temp_mg;
fEul(r+0.5*h,m21,p21,E21,y21,rho21,ma21,mg21,0.5*h);
m22=temp_m;
p22=temp_p;
E22=temp_E;
y22=temp_y;
rho22=temp_rho;
ma22=temp_ma;
mg22=temp_mg;
fEul(r,m,p,E,y,rho,ma,mg,h/3);
m31=temp_m;
p31=temp_p;
E31=temp_E;
y31=temp_y;
fEul(r,m,p,E,y,rho,ma,mg,h/6);
m61=temp_m;
p61=temp_p;
E61=temp_E;
y61=temp_y;
fEul(r+h/6,m61,p61,E61,y61,rho,ma,mg,h/6);
m62=temp_m;
p62=temp_p;
E62=temp_E;
y62=temp_y;
K_m=m22-m21;
K_p=p22-p21;
K_E=E22-E21;
K_y=y22-y21;
K_rho=rho22-rho21;
K_ma=ma22-ma21;
K_mg=mg22-mg21;
fEul(r+0.5*h,m+K_m,p+K_p,E+K_E,y+K_y,rho+K_rho,ma+K_ma,mg+K_mg,h);
A_m=temp_m;
A_p=temp_p;
A_E=temp_E;
A_y=temp_y;
A_rho=temp_rho;
A_ma=temp_ma;
A_mg=temp_mg;
fEul(r+h,A_m-K_m,A_p-K_p,A_E-K_E,A_y-K_y,A_rho-K_rho,A_ma-K_ma,A_mg-K_mg,h);
B_m=temp_m;
B_p=temp_p;
B_E=temp_E;
B_y=temp_y;
B_rho=temp_rho;
B_ma=temp_ma;
B_mg=temp_mg;

if(loopTOV<1) break;

RK_m=0.5*(m+K_m)+(m11+A_m+B_m)/6;
RK_p=0.5*(p+K_p)+(p11+A_p+B_p)/6;
RK_E=0.5*(E+K_E)+(E11+A_E+B_E)/6;
RK_y=0.5*(y+K_y)+(y11+A_y+B_y)/6;
RK_rho=0.5*(rho+K_rho)+(rho11+A_rho+B_rho)/6;
RK_ma=0.5*(ma+K_ma)+(ma11+A_ma+B_ma)/6;
RK_mg=0.5*(mg+K_mg)+(mg11+A_mg+B_mg)/6;
TR_m=m22+9*(m62-m31);
TR_p=p22+9*(p62-p31);
TR_y=y22+9*(y62-y31);

res1=(RK_m>TR_m)?((RK_m-TR_m)/RK_m):((TR_m-RK_m)/RK_m);
res2=(RK_p>TR_p)?((RK_p-TR_p)/RK_p):((TR_p-RK_p)/RK_p);
res3=(RK_y>TR_y)?((RK_y-TR_y)/RK_y):((TR_y-RK_y)/RK_y);
res2=(res2>res3)?res2:res3;
localRes=(res1>res2)?res1:res2;

if(localRes<5e-6 && h<8e-8)
{
r=r+h;
m=RK_m;
p=RK_p;
E=RK_E;
y=RK_y;
rho=RK_rho;
ma=RK_ma;
mg=RK_mg;
h=h*2;
}else if(localRes>2e-4 && h>1.25e-9){
h=h*0.5;
}else{
r=r+h;
m=RK_m;
p=RK_p;
E=RK_E;
y=RK_y;
rho=RK_rho;
ma=RK_ma;
mg=RK_mg;
}
}
double bt=m/r;
temp_R=r*c*1e-3;
temp_M=m*Mscale;
temp_k2=1.6*bt*bt*bt*bt*bt*(1-2*bt)*(1-2*bt)*(2-y+2*bt*(y-1))/(2*bt*(6-3*y+3*bt*(5*y-8))+4*bt*bt*bt*(13-11*y+bt*(3*y-2)+2*bt*bt*(1+y))+3*(1-2*bt)*(1-2*bt)*(2-y+2*bt*(y-1))*log(1-2*bt));
temp_Ma=ma*Mscale;
temp_Mg=mg*Mscale;
return;
}

int ManualS(EOSname)
char EOSname[50];
{
FILE *inf,*outf;
int pf,markpf,n;
double Ec;

if((inf=fopen(EOSname,"r"))==NULL)
{
printf("\nfile not found!\n");
fprintf(scanlog,"\nfile not found!\n");
return 0;
}
while(fscanf(inf,"%lf",&EOS_lgrho[length_EOS])==1)
{
	fscanf(inf,"%lf",&EOS_lgE[length_EOS]);
	fscanf(inf,"%lf%*[^\n]",&EOS_lgp[length_EOS]);
	length_EOS++;
}
E_core=pow(10,EOS_lgE[length_EOS-1]);

for(n=0;n<length_EOS;n++)
{
	EOS_lgrho[n]=EOS_lgrho[n]-10.175607290470733;
	EOS_lgE[n]=EOS_lgE[n]-10.175607290470733;
	EOS_lgp[n]=EOS_lgp[n]-27.129849799910058;
}
p_surf=pow(10,EOS_lgp[0]);

int cnt=0,nlength=strlen(EOSname);
char outname[60];
for(n=nlength;n>nlength-5;n--)
{
EOSname[n]='\0';
}
sprintf(outname,"%c%c%s%c%s%s%s",'.','\\',sT,'\\',"outf_",EOSname,".dat");
outf=fopen(outname,"w");
printf("\n[Manual Mode]: %s EoS is processing\n", EOSname);
fprintf(scanlog,"\n[Manual Mode]: %s EoS is processing\n", EOSname);

pf=0;
Ec=1e18;
fprintf(scanlog,"\n%-10s\t%-6s\t%-8s\t%-6s\t%-11s\t%-6s\n","Ec/(kg.m-3)","M/Msun","R/km","k2","Mbaryon/Msun","Mp/Msun");
for(pf=0;;pf++)
{
printf("\nEnter a central density (0 for exit): ");
fflush(stdin);scanf("%lf",&Ec);
if(Ec<1e13) break;
getRM(Ec);
printf("\n%-10s\t%-6s\t%-8s\t%-6s\t%-11s\t%-6s\n","Ec(kg.m-3)","M(Msun)","R(km)","k2","Mbyon(Msun)","Mp(Msun)");
printf("%-10.4e\t%-6.4lf\t%-8.4lf\t%-6.4lf\t%-11.4lf\t%-6.4lf\n",Ec,temp_M,temp_R,temp_k2,temp_Ma,temp_Mg);
fprintf(scanlog,"%-10.4e\t%-6.4lf\t%-8.4lf\t%-6.4lf\t%-11.4lf\t%-6.4lf\n",Ec,temp_M,temp_R,temp_k2,temp_Ma,temp_Mg);
fprintf(outf,"%-10e\t%-10lf\t%-10lf\t%-10lf\t%-10lf\t%-10lf\n",Ec,temp_M,temp_R,temp_k2,temp_Ma,temp_Mg);
}
fclose(outf);
return 0;
}

int ManualC(EOSname)
char EOSname[50];
{
FILE *inf,*outf;
double sden,eden,Ec=1e18,dstep;
int pf,markpf,n;

if((inf=fopen(EOSname,"r"))==NULL)
{
printf("\nfile not found!\n");
fprintf(scanlog,"\nfile not found!\n");
return 0;
}
while(fscanf(inf,"%lf",&EOS_lgrho[length_EOS])==1)
{
	fscanf(inf,"%lf",&EOS_lgE[length_EOS]);
	fscanf(inf,"%lf%*[^\n]",&EOS_lgp[length_EOS]);
	length_EOS++;
}
E_core=pow(10,EOS_lgE[length_EOS-1]);

for(n=0;n<length_EOS;n++)
{
	EOS_lgrho[n]=EOS_lgrho[n]-10.175607290470733;
	EOS_lgE[n]=EOS_lgE[n]-10.175607290470733;
	EOS_lgp[n]=EOS_lgp[n]-27.129849799910058;
}
p_surf=pow(10,EOS_lgp[0]);

int cnt=0,nlength=strlen(EOSname);
char outname[60];
for(n=nlength;n>nlength-5;n--)
{
EOSname[n]='\0';
}
sprintf(outname,"%c%c%s%c%s%s%s",'.','\\',sT,'\\',"outf_",EOSname,".dat");
outf=fopen(outname,"w");
printf("[Manual Mode]: %s EoS is processing\n", EOSname);
fprintf(scanlog,"[Manual Mode]: %s EoS is processing\n", EOSname);

pf=0;
printf("Enter STARTpoint of central density: ");
fprintf(scanlog,"\nEnter STARTpoint of central density: \n");
fflush(stdin);scanf("%lf",&sden);
printf("Enter ENDpoint of central density: ");
fprintf(scanlog,"\nEnter ENDpoint of central density: \n");
fflush(stdin);scanf("%lf",&eden);
if((eden<1e12)||(eden>5e18)||(sden<1e12)||(sden>5e18))
{
	printf("Warning: wrong inputs.\n");
	fprintf(scanlog,"Warning: wrong inputs.\n");
	fclose(outf);
	return 0;
}
	printf("\n%-10s\t%-6s\t%-8s\t%-6s\t%-11s\t%-6s\n","Ec(kg.m-3)","M(Msun)","R(km)","k2","Mbyon(Msun)","Mp(Msun)");
	fprintf(scanlog,"\n%-10s\t%-6s\t%-8s\t%-6s\t%-11s\t%-6s\n","Ec(kg.m-3)","M(Msun)","R(km)","k2","Mbyon(Msun)","Mp(Msun)");
if(sden==eden)
{
	getRM(sden);
	printf("%-10.4e\t%-6.4lf\t%-8.4lf\t%-6.4lf\t%-11.4lf\t%-6.4lf\n",sden,temp_M,temp_R,temp_k2,temp_Ma,temp_Mg);
	fprintf(scanlog,"%-10.4e\t%-6.4lf\t%-8.4lf\t%-6.4lf\t%-11.4lf\t%-6.4lf\n",sden,temp_M,temp_R,temp_k2,temp_Ma,temp_Mg);
	fprintf(outf,"%-10e\t%-10lf\t%-10lf\t%-10lf\t%-10lf\t%-10lf\n",sden,temp_M,temp_R,temp_k2,temp_Ma,temp_Mg);
}else{
	dstep=(eden-sden)*0.03125;
	pf=-1;
for(Ec=sden;pf<32;Ec=Ec+dstep)
{
	pf++;
getRM(Ec);
printf("%-10.4e\t%-6.4lf\t%-8.4lf\t%-6.4lf\t%-11.4lf\t%-6.4lf\n",Ec,temp_M,temp_R,temp_k2,temp_Ma,temp_Mg);
fprintf(scanlog,"%-10.4e\t%-6.4lf\t%-8.4lf\t%-6.4lf\t%-11.4lf\t%-6.4lf\n",Ec,temp_M,temp_R,temp_k2,temp_Ma,temp_Mg);
fprintf(outf,"%-10e\t%-10lf\t%-10lf\t%-10lf\t%-10lf\t%-10lf\n",Ec,temp_M,temp_R,temp_k2,temp_Ma,temp_Mg);
}
}
fclose(outf);
return 0;
}


int Scan(EOSname)
char EOSname[50];
{
FILE *inf,*outf;
double profile_Ec[300],profile_R[300],profile_M[300],profile_k2[300],profile_Ma[300],profile_Mg[300],deltR;
int pf,markpf,n;

if((inf=fopen(EOSname,"r"))==NULL)
{
printf("\nfile not found!\n");
fprintf(scanlog,"\nfile not found!\n");
return 0;
}
while(fscanf(inf,"%lf",&EOS_lgrho[length_EOS])==1)
{
	fscanf(inf,"%lf",&EOS_lgE[length_EOS]);
	fscanf(inf,"%lf%*[^\n]",&EOS_lgp[length_EOS]);
	length_EOS++;
}
E_core=pow(10,EOS_lgE[length_EOS-1]);

for(n=0;n<length_EOS;n++)
{
	EOS_lgrho[n]=EOS_lgrho[n]-10.175607290470733;
	EOS_lgE[n]=EOS_lgE[n]-10.175607290470733;
	EOS_lgp[n]=EOS_lgp[n]-27.129849799910058;
}
p_surf=pow(10,EOS_lgp[0]);

pf=0;
profile_Ec[pf]=9.000e17;
getRM(profile_Ec[pf]);
profile_R[pf]=temp_R;
profile_M[pf]=temp_M;
profile_k2[pf]=temp_k2;
profile_Ma[pf]=temp_Ma;
profile_Mg[pf]=temp_Mg;
pf++;
profile_Ec[pf]=9.200e17;
getRM(profile_Ec[pf]);
profile_R[pf]=temp_R;
profile_M[pf]=temp_M;
profile_k2[pf]=temp_k2;
profile_Ma[pf]=temp_Ma;
profile_Mg[pf]=temp_Mg;
if((profile_R[0]<23.6)&&(profile_R[0]>6.7)&&(profile_M[0]>0.2)&&(profile_M[0]<3))
{
}else{
printf("\n\n     Unexpected errors occur when generating startpoint of %s\n",EOSname);
fprintf(scanlog,"\n\n     Unexpected errors occur when generating startpoint of %s\n",EOSname);
return 0;
}

while(pf<200)
{
if(profile_Ec[pf]>=E_core)
{
//printf("Warning:EoS out of range!\n");
break;
}
if((profile_M[pf]-profile_M[pf-1]<0.01)&&(profile_M[pf]-profile_M[pf-1]>0))
{
pf++;
profile_Ec[pf]=3*profile_Ec[pf-1]-2*profile_Ec[pf-2];
getRM(profile_Ec[pf]);
profile_R[pf]=temp_R;
profile_M[pf]=temp_M;
profile_k2[pf]=temp_k2;
profile_Ma[pf]=temp_Ma;
profile_Mg[pf]=temp_Mg;
}else if(profile_M[pf]-profile_M[pf-1]<0.05){
pf++;
profile_Ec[pf]=2*profile_Ec[pf-1]-profile_Ec[pf-2];
getRM(profile_Ec[pf]);
profile_R[pf]=temp_R;
profile_M[pf]=temp_M;
profile_k2[pf]=temp_k2;
profile_Ma[pf]=temp_Ma;
profile_Mg[pf]=temp_Mg;
}else{
pf++;
profile_Ec[pf]=profile_Ec[pf-1];
profile_R[pf]=profile_R[pf-1];
profile_M[pf]=profile_M[pf-1];
profile_k2[pf]=profile_k2[pf-1];
profile_Ma[pf]=profile_Ma[pf-1];
profile_Mg[pf]=profile_Mg[pf-1];
profile_Ec[pf-1]=0.618*profile_Ec[pf-2]+0.382*profile_Ec[pf];
getRM(profile_Ec[pf-1]);
profile_R[pf-1]=temp_R;
profile_M[pf-1]=temp_M;
profile_k2[pf-1]=temp_k2;
profile_Ma[pf-1]=temp_Ma;
profile_Mg[pf-1]=temp_Mg;
}
if(profile_M[pf]<=profile_M[pf-1])
{
pf++;
profile_Ec[pf]=profile_Ec[pf-1];
profile_R[pf]=profile_R[pf-1];
profile_M[pf]=profile_M[pf-1];
profile_k2[pf]=profile_k2[pf-1];
profile_Ma[pf]=profile_Ma[pf-1];
profile_Mg[pf]=profile_Mg[pf-1];
profile_Ec[pf-1]=0.618*profile_Ec[pf-2]+0.382*profile_Ec[pf];
getRM(profile_Ec[pf-1]);
profile_R[pf-1]=temp_R;
profile_M[pf-1]=temp_M;
profile_k2[pf-1]=temp_k2;
profile_Ma[pf-1]=temp_Ma;
profile_Mg[pf-1]=temp_Mg;
break;
}
}

markpf=pf;
pf++;
profile_Ec[pf]=profile_Ec[1];
profile_R[pf]=profile_R[1];
profile_M[pf]=profile_M[1];
profile_k2[pf]=profile_k2[1];
profile_Ma[pf]=profile_Ma[1];
profile_Mg[pf]=profile_Mg[1];
pf++;
profile_Ec[pf]=profile_Ec[0];
profile_R[pf]=profile_R[0];
profile_M[pf]=profile_M[0];
profile_k2[pf]=profile_k2[0];
profile_Ma[pf]=profile_Ma[0];
profile_Mg[pf]=profile_Mg[0];
while(pf<300)
{
	deltR=(profile_R[pf-1]>profile_R[pf])?(profile_R[pf-1]-profile_R[pf]):(profile_R[pf]-profile_R[pf-1]);
if((deltR<0.04)&&(profile_M[pf-1]-profile_M[pf]<0.01))
{
pf++;
profile_Ec[pf]=3*profile_Ec[pf-1]-2*profile_Ec[pf-2];
getRM(profile_Ec[pf]);
profile_R[pf]=temp_R;
profile_M[pf]=temp_M;
profile_k2[pf]=temp_k2;
profile_Ma[pf]=temp_Ma;
profile_Mg[pf]=temp_Mg;
}else if((deltR<0.2)&&(profile_M[pf-1]-profile_M[pf])<0.03){
pf++;
profile_Ec[pf]=2*profile_Ec[pf-1]-profile_Ec[pf-2];
getRM(profile_Ec[pf]);
profile_R[pf]=temp_R;
profile_M[pf]=temp_M;
profile_k2[pf]=temp_k2;
profile_Ma[pf]=temp_Ma;
profile_Mg[pf]=temp_Mg;
}else{
pf++;
profile_Ec[pf]=profile_Ec[pf-1];
profile_R[pf]=profile_R[pf-1];
profile_M[pf]=profile_M[pf-1];
profile_k2[pf]=profile_k2[pf-1];
profile_Ma[pf]=profile_Ma[pf-1];
profile_Mg[pf]=profile_Mg[pf-1];
profile_Ec[pf-1]=0.5*profile_Ec[pf-2]+0.5*profile_Ec[pf];
getRM(profile_Ec[pf-1]);
profile_R[pf-1]=temp_R;
profile_M[pf-1]=temp_M;
profile_k2[pf-1]=temp_k2;
profile_Ma[pf-1]=temp_Ma;
profile_Mg[pf-1]=temp_Mg;
}
if((profile_R[pf]>23.6)||(profile_M[pf]<0.18)) break;
}

int cnt=0,nlength=strlen(EOSname);
char outname[60];
for(n=nlength;n>nlength-5;n--)
{
EOSname[n]='\0';
}
sprintf(outname,"%c%c%s%c%s%s%s",'.','\\',sT,'\\',"outf_",EOSname,".dat");

outf=fopen(outname,"w");

for(n=pf;n>markpf;n--)
{
fprintf(outf,"\t%-15e\t%-10lf\t%-10lf\t%-10lf\t%-10lf\t%-10lf\n",profile_Ec[n],profile_M[n],profile_R[n],profile_k2[n],profile_Ma[n],profile_Mg[n]);cnt++;
}
for(n=0;n<markpf+1;n++)
{
if(profile_Ec[n]>profile_Ec[markpf+1])
{
fprintf(outf,"\t%-15e\t%-10lf\t%-10lf\t%-10lf\t%-10lf\t%-10lf\n",profile_Ec[n],profile_M[n],profile_R[n],profile_k2[n],profile_Ma[n],profile_Mg[n]);cnt++;
}
}

fclose(outf);

double x1=profile_R[markpf],y1=profile_M[markpf],x2=profile_R[markpf-1],y2=profile_M[markpf-1],x3=profile_R[markpf-2],y3=profile_M[markpf-2];
double LA=y1/(x1-x2)/(x1-x3)-y2/(x1-x2)/(x2-x3)+y3/(x1-x3)/(x2-x3),LB=-y1*(x2+x3)/(x1-x2)/(x1-x3)+y2*(x1+x3)/(x1-x2)/(x2-x3)-y3*(x1+x2)/(x1-x3)/(x2-x3),LC=y1*x2*x3/(x1-x2)/(x1-x3)-y2*x1*x3/(x1-x2)/(x2-x3)+y3*x1*x2/(x1-x3)/(x2-x3);
double Mmax=LC-0.25*LB*LB/LA;
printf("\n\t%-10s\t%-10f\t%-8d\n",EOSname,Mmax,cnt);
fprintf(scanlog,"\n\t%-10s\t%-10f\t%-8d\n",EOSname,Mmax,cnt);
for(n=0;n<length_EOS;n++){
EOS_lgE[n]='\0';
EOS_lgp[n]='\0';
}
length_EOS=0,loopTOV=1;
return 0;
}

int main()
{
FILE *mdir;
char tpEOS[50],decklog[50];
int n=0,k=0,mode;
time_t timep;
struct tm *p;
time(&timep);
p=gmtime(&timep);
sprintf(sT,"%s%d%d%d%d%d%d","Results_",1900+p->tm_year,1+p->tm_mon,p->tm_mday,8+p->tm_hour,p->tm_min,p->tm_sec);
sprintf(decklog,"%c%c%s%c%s",'.','\\',sT,'\\',"ScreenRecord.log");
system("title Auto Scanning Radius Mass by Chan --- ver 3.3    for Windows");
printf("\nPlease ensure only EoS files at root path are *.txt files before scanning\n(but no need to worry about readme.txt)\n\nPress any key to START scanning process\n");
system("pause");
mkdir(sT);
scanlog=fopen(decklog,"a");
mdir=fopen("temp_dir.dat","w");
fclose(mdir);
system("dir *.txt /B /A-R /ON >> temp_dir.dat");
if((mdir=fopen("temp_dir.dat","r"))==NULL){
printf("\nNo EoS *.txt files detected, press any key to exit..");
fclose(scanlog);
system("pause");
return 0;
}

printf("\n\nSelect a Central Densities mode:\t\n[0]\tManual Mode S (tests a specific point each time)\t\n[1]\tManual Mode C (give startpoint and endpoint to scan)\t\n[2]\tAutomatical Mode (auto scanning for rough M-R curves)\n\nEnter a Mode serial number: ");
fflush(stdin);scanf("%d",&mode);

if(mode==0)
{
	while(fscanf(mdir,"%s",tpEOS)>0)
	{
		k++;
		ManualS(tpEOS);
		for(n=0;n<50;n++)
		{
			tpEOS[n]='\0';
		}
	}
}else if(mode==1){
	while(fscanf(mdir,"%s",tpEOS)>0)
	{
		k++;
		ManualC(tpEOS);
		for(n=0;n<50;n++)
		{
			tpEOS[n]='\0';
		}
	}
}else{
printf("\nExecuting scanning process..\n\n\t%-10s\t%-10s\t%-15s\n","EoS","Mmax(Msun)","Active Points");
fprintf(scanlog,"\nExecuting scanning process..\n\n\t%-10s\t%-10s\t%-15s\n","EoS","Mmax(Msun)","Active Points");
while(fscanf(mdir,"%s",tpEOS)>0)
{
k++;
Scan(tpEOS);
for(n=0;n<50;n++)
{
tpEOS[n]='\0';
}
}
}

fclose(mdir);
remove("temp_dir.dat");
printf("\n\nScanning process has finished, %d available results are saved separately.\n\n(e.g. Results for [EoS_L32.txt] would be saved as [outf_EoS_L32.dat])\n\nPress any key to left\n",k);
fprintf(scanlog,"\n\nScanning process has finished, %d available results are saved separately.\n\n(e.g. Results for [EoS_L32.txt] would be saved as [outf_EoS_L32.dat])\n\nPress any key to left\n",k);
fclose(scanlog);
system("pause");
return 0;
}